//
//  SellerSettingsViewController.swift
//  The Green Merchant
//
//  Created by Paul Austria on 16/03/2019.
//  Copyright © 2019 Paul Austria. All rights reserved.
//

import UIKit

class SellerSettingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
    
    
}
