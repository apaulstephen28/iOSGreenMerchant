//
//  LoginView.swift
//  The Green Merchant
//
//  Created by Paul Austria on 01/03/2019.
//  Copyright © 2019 Paul Austria. All rights reserved.
//

import UIKit
import Alamofire
class LoginView: UIView {

    @IBAction func btnLogout(_ sender: Any) {
        self.isHidden = true
    }
    
}
